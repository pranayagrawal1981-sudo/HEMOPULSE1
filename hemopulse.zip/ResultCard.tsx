import { Building2, Hospital, User, Phone, MapPin, Navigation, Lock, AlertTriangle, BadgeCheck } from "lucide-react";
import type { Source } from "@/lib/mock-data";
import { directionsUrl } from "@/lib/integrations";
import { useI18n } from "@/lib/i18n";

const icons = { bank: Building2, hospital: Hospital, donor: User };
const typeLabel = { bank: "Blood bank", hospital: "Hospital", donor: "Donor" };

export function ResultCard({ s, onMap }: { s: Source & { score?: number; alternative?: boolean }; onMap?: () => void }) {
  const { t } = useI18n();
  const Icon = icons[s.type];
  const nearExpiry = s.expiryDays <= 3;
  const hidden = s.type === "donor" && !s.consent;
  return (
    <article className="rounded-3xl border bg-card p-5 shadow-soft">
      <div className="flex items-start gap-4">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-secondary text-primary"><Icon /></div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-bold">{s.name}</h3>
            {s.verified && <BadgeCheck className="h-5 w-5 text-safe" aria-label="Verified" />}
          </div>
          <p className="text-sm text-muted-foreground">{typeLabel[s.type]} · {s.address}</p>
        </div>
        {s.status !== "idle" && (
          <span className={`rounded-full px-3 py-1 text-sm font-semibold ${s.status === "accepted" ? "bg-safe-soft text-safe" : "bg-warn-soft text-warn"}`}>
            {t(s.status)}
          </span>
        )}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
        <div className="rounded-2xl bg-muted p-3"><div className="text-muted-foreground">{t("bloodGroup")}</div><div className="text-lg font-bold text-primary">{s.group} · {s.units}u</div></div>
        <div className={`rounded-2xl p-3 ${nearExpiry ? "bg-warn-soft" : "bg-safe-soft"}`}><div className="text-muted-foreground">{t("expires")}</div><div className={`text-lg font-bold ${nearExpiry ? "text-warn" : "text-safe"}`}>{s.expiryDays}d</div></div>
        <div className="rounded-2xl bg-muted p-3"><div className="text-muted-foreground"><MapPin className="inline h-3 w-3" /> </div><div className="text-lg font-bold">{s.distanceKm} {t("kmAway")}</div></div>
        <div className="rounded-2xl bg-muted p-3"><div className="text-muted-foreground">{t("updated")}</div><div className="text-lg font-bold">{s.updatedMin} {t("minAgo")}</div></div>
      </div>
      {s.alternative && (
        <p className="mt-3 flex items-center gap-2 rounded-2xl bg-warn-soft p-3 text-sm font-medium text-warn">
          <AlertTriangle className="h-4 w-4" /> Safe alternative — {t("doctorConfirm")}
        </p>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        {hidden ? (
          <span className="inline-flex h-12 items-center gap-2 rounded-full border px-5 text-muted-foreground"><Lock className="h-4 w-4" /> {t("hidden")}</span>
        ) : (
          <a href={`tel:${s.phone}`} className="inline-flex h-12 items-center gap-2 rounded-full bg-crimson px-6 font-bold text-primary-foreground shadow-lift">
            <Phone className="h-5 w-5" /> {t("call")}
          </a>
        )}
        {onMap && <button onClick={onMap} className="inline-flex h-12 items-center gap-2 rounded-full border px-5 font-medium"><MapPin className="h-5 w-5" /> {t("viewMap")}</button>}
        <a href={directionsUrl(s.lat, s.lng)} target="_blank" rel="noreferrer" className="inline-flex h-12 items-center gap-2 rounded-full border px-5 font-medium"><Navigation className="h-5 w-5" /> {t("directions")}</a>
      </div>
    </article>
  );
}
