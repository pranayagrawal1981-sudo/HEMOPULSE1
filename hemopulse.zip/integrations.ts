/**
 * ================= INTEGRATION LAYER =================
 * Every external service is stubbed here so real APIs can be plugged in
 * without touching the UI. Each stub returns realistic mock responses.
 *
 *  [OTP]       MSG91 / Twilio Verify (SMS + WhatsApp)   -> sendOtp, verifyOtp
 *  [NOTIFY]    SMS + WhatsApp + Push (FCM)              -> notifySources, smsFallback
 *  [REALTIME]  Supabase Realtime / Firebase             -> subscribeStock
 *  [MAPS]      Google Maps JS + Routes API              -> mapEmbedUrl, directionsUrl
 *  [AMBULANCE] 108 / partner dispatch API               -> dispatchAmbulance
 *  [AI]        LLM for matching + assistant             -> (see Assistant component)
 * =====================================================
 */
import { CITY_STOCK, type BloodGroup } from "./mock-data";

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---- [OTP] ----
const otpAttempts = new Map<string, number[]>();
export async function sendOtp(mobile: string) {
  // Client-side rate limit mock: max 3 OTPs per 10 minutes. Enforce server-side in production.
  const now = Date.now();
  const recent = (otpAttempts.get(mobile) ?? []).filter((t) => now - t < 600_000);
  if (recent.length >= 3) return { ok: false, error: "Too many OTP requests. Try again in 10 minutes." };
  otpAttempts.set(mobile, [...recent, now]);
  await wait(700);
  return { ok: true, channels: ["SMS", "WhatsApp"] }; // demo OTP: 123456
}
export async function verifyOtp(_mobile: string, code: string) {
  await wait(600);
  return code === "123456" ? { ok: true } : { ok: false, error: "Wrong OTP. Please check and try again." };
}

// ---- [NOTIFY] ----
export async function notifySources(ids: string[]) {
  await wait(300);
  return ids.map((id) => ({ id, push: true, sms: true, whatsapp: true }));
}
export async function smsFallback(mobile: string, message: string) {
  console.info("[SMS fallback]", mobile, message);
  return { ok: true };
}

// ---- [REALTIME] ----
export function subscribeStock(cb: (s: Record<BloodGroup, number>) => void) {
  let stock = { ...CITY_STOCK };
  cb(stock);
  const id = setInterval(() => {
    const keys = Object.keys(stock) as BloodGroup[];
    const k = keys[Math.floor(Math.random() * keys.length)]!;
    stock = { ...stock, [k]: Math.max(0, stock[k] + (Math.random() > 0.5 ? 1 : -1)) };
    cb(stock);
  }, 4000);
  return () => clearInterval(id);
}

// ---- [MAPS] ---- (keyless embed for demo; swap to Maps JS API with a key)
export const mapEmbedUrl = (q: string) =>
  `https://maps.google.com/maps?q=${encodeURIComponent(q)}&z=12&output=embed`;
export const directionsUrl = (lat: number, lng: number) =>
  `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;

// ---- [AMBULANCE] ----
export async function dispatchAmbulance(_pickup: string) {
  await wait(900);
  return { ok: true, vehicle: "DL 1C AB 1080", etaMin: 12, driverPhone: "+91108" };
}
