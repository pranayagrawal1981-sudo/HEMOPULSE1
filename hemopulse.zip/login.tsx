import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { Smartphone, ShieldCheck, Building2, User, HeartHandshake } from "lucide-react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { sendOtp, verifyOtp } from "@/lib/integrations";
import { useI18n } from "@/lib/i18n";

const roles = ["donor", "receiver", "center"] as const;
export const Route = createFileRoute("/login")({
  validateSearch: (s) => z.object({ role: z.enum(roles).catch("receiver") }).parse(s),
  head: () => ({
    meta: [
      { title: "Login with OTP — HemoPulse" },
      { name: "description", content: "Secure OTP-only login for donors, receivers and blood centers. No passwords." },
      { property: "og:title", content: "Login with OTP — HemoPulse" },
      { property: "og:description", content: "Passwordless login via SMS and WhatsApp OTP." },
    ],
  }),
  component: Login,
});

const roleMeta = {
  donor: { icon: HeartHandshake, key: "donorLogin", to: "/dashboard/donor" },
  receiver: { icon: User, key: "receiverLogin", to: "/dashboard/receiver" },
  center: { icon: Building2, key: "centerLogin", to: "/dashboard/center" },
} as const;

function Login() {
  const { role } = Route.useSearch();
  const nav = useNavigate();
  const { t } = useI18n();
  const [mobile, setMobile] = useState("");
  const [license, setLicense] = useState("");
  const [step, setStep] = useState<"phone" | "otp" | "pending">("phone");
  const [otp, setOtp] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [timer, setTimer] = useState(0);

  useEffect(() => { setStep("phone"); setErr(""); }, [role]);
  useEffect(() => { if (timer <= 0) return; const id = setTimeout(() => setTimer(timer - 1), 1000); return () => clearTimeout(id); }, [timer]);

  async function send() {
    setErr("");
    if (!/^[6-9]\d{9}$/.test(mobile)) return setErr("Enter a valid 10-digit Indian mobile number.");
    if (role === "center" && license.trim().length < 6) return setErr("Enter your blood bank license number.");
    setBusy(true); const r = await sendOtp(mobile); setBusy(false);
    if (!r.ok) return setErr(r.error!);
    setStep("otp"); setTimer(30);
  }
  async function verify() {
    setBusy(true); const r = await verifyOtp(mobile, otp); setBusy(false);
    if (!r.ok) return setErr(r.error!);
    if (role === "center") return setStep("pending");
    nav({ to: roleMeta[role].to });
  }

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="mb-5 grid grid-cols-3 gap-2 rounded-full border bg-card p-1">
        {roles.map((r) => (
          <button key={r} onClick={() => nav({ to: "/login", search: { role: r } })} className={`h-11 rounded-full text-sm font-semibold ${role === r ? "bg-primary text-primary-foreground" : ""}`}>
            {r === "center" ? "Center" : r === "donor" ? "Donor" : "Receiver"}
          </button>
        ))}
      </div>
      <div className="rounded-3xl border bg-card p-6 shadow-soft md:p-8">
        <h1 className="text-2xl font-extrabold">{t(roleMeta[role].key)}</h1>
        <p className="mt-1 text-muted-foreground">OTP only · no passwords</p>

        {step === "phone" && (
          <div className="mt-6 space-y-4">
            <label className="block"><span className="mb-2 block font-semibold">{t("mobile")}</span>
              <div className="flex h-14 items-center rounded-2xl border bg-background">
                <span className="flex items-center gap-1 border-r px-4 font-semibold"><Smartphone className="h-4 w-4" />+91</span>
                <input value={mobile} onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))} inputMode="numeric" className="h-full flex-1 bg-transparent px-4 text-lg" placeholder="98XXXXXXXX" />
              </div>
            </label>
            {role === "center" && (
              <label className="block"><span className="mb-2 block font-semibold">Blood bank license no.</span>
                <input value={license} onChange={(e) => setLicense(e.target.value)} className="h-14 w-full rounded-2xl border bg-background px-4 text-lg" placeholder="DL-BB-2024-XXXX" />
              </label>
            )}
            <button onClick={send} disabled={busy} className="h-14 w-full rounded-2xl bg-crimson text-lg font-bold text-primary-foreground disabled:opacity-60">{busy ? "…" : t("sendOtp")}</button>
          </div>
        )}

        {step === "otp" && (
          <div className="mt-6 space-y-4">
            <p>OTP sent to +91 {mobile} via SMS & WhatsApp. <span className="text-muted-foreground">(Demo: 123456)</span></p>
            <InputOTP maxLength={6} value={otp} onChange={setOtp}>
              <InputOTPGroup>{[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} className="h-14 w-12 text-xl" />)}</InputOTPGroup>
            </InputOTP>
            <button onClick={verify} disabled={busy || otp.length < 6} className="h-14 w-full rounded-2xl bg-crimson text-lg font-bold text-primary-foreground disabled:opacity-60">{t("verify")}</button>
            <button onClick={send} disabled={timer > 0} className="h-12 w-full rounded-2xl border font-medium disabled:text-muted-foreground">
              {timer > 0 ? `${t("resendIn")} ${timer}s` : t("resend")}
            </button>
          </div>
        )}

        {step === "pending" && (
          <div className="mt-6 rounded-2xl bg-warn-soft p-5">
            <p className="font-bold text-warn">License under verification</p>
            <p className="mt-1">An admin is reviewing license {license}. You can preview the dashboard meanwhile.</p>
            <button onClick={() => nav({ to: "/dashboard/center" })} className="mt-4 h-12 rounded-full bg-navy px-6 font-bold text-primary-foreground">Preview dashboard</button>
          </div>
        )}

        {err && <p role="alert" className="mt-4 rounded-2xl bg-critical-soft p-3 font-medium text-critical">{err}</p>}
        <p className="mt-6 flex items-start gap-2 text-sm text-muted-foreground"><ShieldCheck className="h-4 w-4 shrink-0 text-safe" /> Max 3 OTPs per 10 minutes. Donor contact details stay hidden until the donor consents.</p>
      </div>
    </div>
  );
}
