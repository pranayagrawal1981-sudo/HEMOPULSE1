import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CheckCircle2, Circle, Phone, MessageSquare } from "lucide-react";
import { mapEmbedUrl } from "@/lib/integrations";
import { LiveBadge } from "@/components/hp/StockStrip";

export const Route = createFileRoute("/track/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `Tracking ${params.id} — HemoPulse` },
      { name: "description", content: "Live status, ETA and map for your blood request." },
      { property: "og:title", content: "Live blood request tracking — HemoPulse" },
      { property: "og:description", content: "Follow your blood request in real time." },
    ],
  }),
  component: Track,
});

const stages = ["Request sent", "Source accepted", "Units cross-matched", "Out for delivery", "Delivered"];

function Track() {
  const { id } = Route.useParams();
  const [stage, setStage] = useState(1);
  const [eta, setEta] = useState(18);
  useEffect(() => {
    const a = setInterval(() => setStage((s) => Math.min(4, s + 1)), 9000);
    const b = setInterval(() => setEta((e) => Math.max(0, e - 1)), 4000);
    return () => { clearInterval(a); clearInterval(b); };
  }, []);
  return (
    <div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 lg:grid-cols-[1fr_1.3fr]">
      <div className="space-y-5">
        <div className="flex items-center gap-3"><h1 className="text-3xl font-extrabold">{id}</h1><LiveBadge /></div>
        <div className="rounded-3xl bg-crimson p-6 text-primary-foreground">
          <p className="opacity-90">ETA</p><p className="text-5xl font-extrabold">{eta} min</p>
          <p className="mt-2">AIIMS Blood Bank → your hospital</p>
        </div>
        <ol className="space-y-3 rounded-3xl border bg-card p-6 shadow-soft">
          {stages.map((s, i) => (
            <li key={s} className="flex items-center gap-3 text-lg">
              {i <= stage ? <CheckCircle2 className="text-safe" /> : <Circle className="text-border" />}
              <span className={i <= stage ? "font-semibold" : "text-muted-foreground"}>{s}</span>
            </li>
          ))}
        </ol>
        <div className="flex flex-wrap gap-3">
          <a href="tel:+911126588500" className="inline-flex h-12 items-center gap-2 rounded-full bg-navy px-6 font-bold text-primary-foreground"><Phone /> Call blood bank</a>
          <span className="inline-flex h-12 items-center gap-2 rounded-full border px-5 text-sm"><MessageSquare className="h-4 w-4" /> SMS updates on</span>
        </div>
      </div>
      <iframe title="Live map" src={mapEmbedUrl("AIIMS Blood Bank New Delhi")} className="h-[520px] w-full rounded-3xl border shadow-soft" loading="lazy" />
    </div>
  );
}
