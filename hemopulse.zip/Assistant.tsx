/**
 * [AI] Floating assistant. Currently a scripted, step-by-step form filler so
 * it works offline. To plug in a real LLM, replace `nextReply` with a call to
 * your AI server function and keep the same message format.
 */
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { MessageCircle, Mic, Phone, Send, X } from "lucide-react";
import { LogoMark } from "./Logo";
import { useI18n } from "@/lib/i18n";
import { BLOOD_GROUPS, type BloodGroup } from "@/lib/mock-data";

type Msg = { from: "bot" | "me"; text: string };
type Draft = { group?: BloodGroup; units?: number; location?: string; urgency?: string };

const copy = {
  en: {
    hi: "Hi! I can find blood for you. What blood group do you need?",
    units: "How many units?", loc: "Which city or hospital area?", urg: "How urgent? (critical / urgent / planned)",
    confirm: (d: Draft) => `Please confirm: ${d.units} unit(s) of ${d.group} near ${d.location}, ${d.urgency}. Type "yes" to send.`,
    sent: "Sending your request to nearby blood banks now…", retry: "Sorry, I didn't get that. Please try again.",
    help: "I can also help you log in or find a donation camp. Just ask!",
  },
  hi: {
    hi: "नमस्ते! मैं आपके लिए खून ढूंढ सकता हूँ। कौन सा ब्लड ग्रुप चाहिए?",
    units: "कितनी यूनिट?", loc: "कौन सा शहर या अस्पताल क्षेत्र?", urg: "कितना ज़रूरी? (गंभीर / जल्दी / नियोजित)",
    confirm: (d: Draft) => `पुष्टि करें: ${d.location} के पास ${d.group} की ${d.units} यूनिट, ${d.urgency}। भेजने के लिए "हाँ" लिखें।`,
    sent: "आपका अनुरोध पास के ब्लड बैंकों को भेजा जा रहा है…", retry: "माफ़ कीजिए, समझ नहीं आया। फिर से लिखें।",
    help: "मैं लॉगिन या रक्तदान शिविर ढूंढने में भी मदद कर सकता हूँ।",
  },
};

export function Assistant() {
  const { t, lang } = useI18n();
  const c = copy[lang];
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [draft, setDraft] = useState<Draft>({});
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  useEffect(() => { if (open && msgs.length === 0) setMsgs([{ from: "bot", text: c.hi }]); }, [open]); // eslint-disable-line
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  function reply(text: string) {
    const v = text.trim();
    const d = { ...draft };
    let bot = c.retry;
    if (/camp|शिविर/i.test(v)) { nav({ to: "/camps" }); bot = c.help; }
    else if (/login|लॉगिन/i.test(v)) { nav({ to: "/login", search: { role: "receiver" } }); bot = c.help; }
    else if (!d.group) {
      const g = BLOOD_GROUPS.find((b) => v.toUpperCase().replace(/\s|POSITIVE|POS/g, (m) => (m.startsWith("P") ? "+" : "")).includes(b));
      if (g) { d.group = g; bot = c.units; }
    } else if (!d.units) {
      const n = parseInt(v); if (n > 0 && n < 50) { d.units = n; bot = c.loc; }
    } else if (!d.location) { d.location = v; bot = c.urg; }
    else if (!d.urgency) { d.urgency = v; bot = c.confirm(d); }
    else if (/^(yes|y|haan|हाँ|हां)/i.test(v)) {
      bot = c.sent;
      setTimeout(() => {
        nav({ to: "/emergency", search: { group: d.group, units: d.units, location: d.location, auto: true } });
        setOpen(false); setDraft({}); setMsgs([]);
      }, 900);
    }
    setDraft(d);
    setMsgs((m) => [...m, { from: "me", text: v }, { from: "bot", text: bot }]);
    speak(bot);
  }

  function speak(text: string) {
    if (!listening || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const u = new SpeechSynthesisUtterance(text); u.lang = lang === "hi" ? "hi-IN" : "en-IN";
    window.speechSynthesis.speak(u);
  }

  function voice() {
    const SR = (window as unknown as { SpeechRecognition?: any; webkitSpeechRecognition?: any });
    const Rec = SR.SpeechRecognition || SR.webkitSpeechRecognition;
    if (!Rec) { setMsgs((m) => [...m, { from: "bot", text: "Voice input isn't supported on this browser." }]); return; }
    const r = new Rec(); r.lang = lang === "hi" ? "hi-IN" : "en-IN";
    setListening(true);
    r.onresult = (e: any) => reply(e.results[0][0].transcript);
    r.onend = () => setListening(false);
    r.start();
  }

  return (
    <>
      <button onClick={() => setOpen(!open)} className="fixed bottom-5 right-5 z-50 flex h-16 w-16 items-center justify-center rounded-full bg-navy text-primary-foreground shadow-lift" aria-label={t("assistant")}>
        {open ? <X /> : <MessageCircle className="h-7 w-7" />}
      </button>
      {open && (
        <div className="fixed bottom-24 right-3 z-50 flex h-[70vh] max-h-[560px] w-[calc(100vw-1.5rem)] max-w-sm flex-col overflow-hidden rounded-3xl border bg-card shadow-lift" role="dialog" aria-label={t("assistant")}>
          <div className="flex items-center gap-3 bg-crimson p-4 text-primary-foreground">
            <span className="rounded-full bg-card p-1"><LogoMark className="h-7 w-7" /></span>
            <div className="flex-1"><p className="font-bold">{t("assistant")}</p><p className="text-xs opacity-90">English · हिन्दी</p></div>
            <a href="tel:1800110011" className="flex h-10 items-center gap-1 rounded-full bg-card px-3 text-sm font-semibold text-primary" title={t("callAI")}><Phone className="h-4 w-4" /> {t("call")}</a>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {msgs.map((m, i) => (
              <div key={i} className={`max-w-[85%] rounded-2xl px-4 py-2 ${m.from === "me" ? "ml-auto bg-primary text-primary-foreground" : "bg-muted"}`}>{m.text}</div>
            ))}
            {!draft.group && msgs.length <= 1 && (
              <div className="flex flex-wrap gap-2">{BLOOD_GROUPS.map((g) => <button key={g} onClick={() => reply(g)} className="h-10 rounded-full border px-3 font-semibold">{g}</button>)}</div>
            )}
            <div ref={end} />
          </div>
          <form className="flex gap-2 border-t p-3" onSubmit={(e) => { e.preventDefault(); if (input.trim()) { reply(input); setInput(""); } }}>
            <button type="button" onClick={voice} className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full border ${listening ? "bg-primary text-primary-foreground" : ""}`} aria-label="Voice input"><Mic /></button>
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={t("askAnything")} className="h-12 min-w-0 flex-1 rounded-full border bg-background px-4" />
            <button className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground" aria-label="Send"><Send className="h-5 w-5" /></button>
          </form>
        </div>
      )}
    </>
  );
}
