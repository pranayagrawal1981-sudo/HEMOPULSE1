import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Calendar, MapPin, Navigation, Bell, CheckCircle2, XCircle } from "lucide-react";
import { CAMPS } from "@/lib/mock-data";
import { directionsUrl, mapEmbedUrl } from "@/lib/integrations";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/camps")({
  head: () => ({
    meta: [
      { title: "Blood donation camps near you — HemoPulse" },
      { name: "description", content: "Find, register and get reminders for blood donation camps near you. Check your eligibility in seconds." },
      { property: "og:title", content: "Blood donation camps near you — HemoPulse" },
      { property: "og:description", content: "Nearby donation camps with maps, directions and reminders." },
    ],
  }),
  component: Camps,
});

function Eligibility() {
  const [age, setAge] = useState(""); const [weight, setWeight] = useState(""); const [last, setLast] = useState("");
  const days = last ? Math.floor((Date.now() - new Date(last).getTime()) / 864e5) : 999;
  const filled = age && weight;
  const ok = +age >= 18 && +age <= 65 && +weight >= 50 && days >= 90;
  const cls = "h-14 w-full rounded-2xl border bg-background px-4 text-lg";
  return (
    <div className="rounded-3xl border bg-card p-6 shadow-soft">
      <h2 className="text-xl font-bold">Can I donate? Quick check</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <label><span className="mb-1 block text-sm font-medium">Age</span><input type="number" value={age} onChange={(e) => setAge(e.target.value)} className={cls} /></label>
        <label><span className="mb-1 block text-sm font-medium">Weight (kg)</span><input type="number" value={weight} onChange={(e) => setWeight(e.target.value)} className={cls} /></label>
        <label><span className="mb-1 block text-sm font-medium">Last donation</span><input type="date" value={last} onChange={(e) => setLast(e.target.value)} className={cls} /></label>
      </div>
      {filled && (
        <p className={`mt-4 flex items-center gap-2 rounded-2xl p-4 font-semibold ${ok ? "bg-safe-soft text-safe" : "bg-warn-soft text-warn"}`}>
          {ok ? <CheckCircle2 /> : <XCircle />}
          {ok ? "You look eligible! Register at a camp below." : days < 90 ? `Please wait ${90 - days} more days since your last donation.` : "You need to be 18–65 years and at least 50 kg."}
        </p>
      )}
    </div>
  );
}

function Camps() {
  const { t } = useI18n();
  const [maxKm, setMaxKm] = useState(25);
  const [date, setDate] = useState("");
  const [focus, setFocus] = useState(CAMPS[0]!);
  const list = CAMPS.filter((c) => c.km <= maxKm && (!date || c.date >= date));
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">{t("camps")}</h1>
      <div className="mt-6"><Eligibility /></div>
      <div className="mt-6 flex flex-wrap items-end gap-4">
        <label><span className="mb-1 block text-sm font-medium">From date</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="h-12 rounded-2xl border bg-card px-4" /></label>
        <label className="min-w-56"><span className="mb-1 block text-sm font-medium">Within {maxKm} km</span><input type="range" min={2} max={25} value={maxKm} onChange={(e) => setMaxKm(+e.target.value)} className="w-full accent-[var(--color-primary)]" /></label>
      </div>
      <div className="mt-6 grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <div className="space-y-4">
          {list.length === 0 && <p className="rounded-3xl border bg-card p-6 text-muted-foreground">No camps match. Try a wider distance.</p>}
          {list.map((c) => (
            <article key={c.id} className="rounded-3xl border bg-card p-5 shadow-soft">
              <h3 className="text-lg font-bold">{c.name}</h3>
              <p className="text-muted-foreground">{c.org}</p>
              <div className="mt-3 flex flex-wrap gap-4 text-sm">
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4 text-primary" />{new Date(c.date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })} · {c.time}</span>
                <span className="flex items-center gap-1"><MapPin className="h-4 w-4 text-primary" />{c.address} · {c.km} km</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <button onClick={() => toast.success(`Registered for ${c.name}`)} className="h-12 rounded-full bg-crimson px-6 font-bold text-primary-foreground">{t("register")}</button>
                <button onClick={() => toast.success("We'll remind you by SMS a day before")} className="inline-flex h-12 items-center gap-2 rounded-full border px-5"><Bell className="h-4 w-4" />{t("remindMe")}</button>
                <button onClick={() => setFocus(c)} className="inline-flex h-12 items-center gap-2 rounded-full border px-5"><MapPin className="h-4 w-4" />{t("viewMap")}</button>
                <a href={directionsUrl(c.lat, c.lng)} target="_blank" rel="noreferrer" className="inline-flex h-12 items-center gap-2 rounded-full border px-5"><Navigation className="h-4 w-4" />{t("directions")}</a>
              </div>
            </article>
          ))}
        </div>
        <iframe title="Camp map" src={mapEmbedUrl(`${focus.lat},${focus.lng}`)} className="sticky top-24 h-[480px] w-full rounded-3xl border shadow-soft" loading="lazy" />
      </div>
    </div>
  );
}
