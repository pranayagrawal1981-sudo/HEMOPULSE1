import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/dashboard/receiver")({
  head: () => ({
    meta: [
      { title: "Receiver dashboard — HemoPulse" },
      { name: "description", content: "HemoPulse receiver dashboard." },
      { property: "og:title", content: "Receiver dashboard — HemoPulse" },
      { property: "og:description", content: "HemoPulse receiver dashboard." },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <h1 className="text-3xl font-extrabold">Receiver dashboard</h1>
      <p className="mt-3 text-muted-foreground">Coming soon.</p>
    </div>
  ),
});
