import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/dashboard/donor")({
  head: () => ({
    meta: [
      { title: "Donor dashboard — HemoPulse" },
      { name: "description", content: "HemoPulse donor dashboard." },
      { property: "og:title", content: "Donor dashboard — HemoPulse" },
      { property: "og:description", content: "HemoPulse donor dashboard." },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <h1 className="text-3xl font-extrabold">Donor dashboard</h1>
      <p className="mt-3 text-muted-foreground">Coming soon.</p>
    </div>
  ),
});
