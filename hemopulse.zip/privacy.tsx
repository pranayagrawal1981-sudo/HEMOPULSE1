import { createFileRoute } from "@tanstack/react-router";
import { Lock, ShieldCheck, FileText, UserCheck, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy & consent — HemoPulse" },
      { name: "description", content: "How HemoPulse protects your data: encryption, role-based access, audit logs and consent-first donor contact." },
      { property: "og:title", content: "Privacy & consent — HemoPulse" },
      { property: "og:description", content: "Encryption, consent and medical safety at HemoPulse." },
    ],
  }),
  component: Privacy,
});

const items = [
  { icon: Lock, t: "Encryption", d: "All data is encrypted in transit (TLS) and at rest." },
  { icon: UserCheck, t: "Role-based access", d: "Donors, receivers, blood centers and admins only see what their role allows." },
  { icon: FileText, t: "Audit logs", d: "Every access to sensitive data is logged and reviewable." },
  { icon: ShieldCheck, t: "Verified network", d: "Blood banks are license-verified; donors are OTP-verified. OTPs are rate-limited." },
  { icon: Lock, t: "Consent first", d: "Donor phone numbers are never shown until the donor accepts a specific request." },
  { icon: AlertTriangle, t: "Medical disclaimer", d: "Blood group substitutions (e.g. O- for urgent cases) must always be confirmed by a doctor or hospital." },
];

function Privacy() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">Privacy & consent</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {items.map((i) => (
          <div key={i.t} className="rounded-3xl border bg-card p-6 shadow-soft">
            <i.icon className="h-8 w-8 text-primary" />
            <h2 className="mt-3 text-lg font-bold">{i.t}</h2>
            <p className="mt-1 text-muted-foreground">{i.d}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
