import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Siren, LocateFixed, Ambulance, MessageSquare, Radar, BellRing, CheckCircle2, Timer } from "lucide-react";
import { BLOOD_GROUPS, rankSources, type BloodGroup } from "@/lib/mock-data";
import { dispatchAmbulance, notifySources, smsFallback } from "@/lib/integrations";
import { ResultsView } from "@/components/hp/ResultsView";
import { useI18n } from "@/lib/i18n";

const schema = z.object({
  group: z.enum(BLOOD_GROUPS).optional().catch(undefined),
  units: z.coerce.number().optional().catch(undefined),
  location: z.string().optional().catch(undefined),
  auto: z.boolean().optional().catch(undefined),
});

export const Route = createFileRoute("/emergency")({
  validateSearch: (s) => schema.parse(s),
  head: () => ({
    meta: [
      { title: "Emergency blood request — HemoPulse" },
      { name: "description", content: "Request blood in under 60 seconds. No login needed. AI alerts the top 5 nearby sources instantly." },
      { property: "og:title", content: "Emergency blood request — HemoPulse" },
      { property: "og:description", content: "No-login emergency blood request with live tracking." },
    ],
  }),
  component: Emergency,
});

const field = "h-14 w-full rounded-2xl border bg-background px-4 text-lg";

function Emergency() {
  const { t } = useI18n();
  const sp = Route.useSearch();
  const [phase, setPhase] = useState<"form" | "searching" | "results">("form");
  const [group, setGroup] = useState<BloodGroup>(sp.group ?? "O+");
  const [units, setUnits] = useState(sp.units ?? 1);
  const [location, setLocation] = useState(sp.location ?? "");
  const [urgency, setUrgency] = useState<"critical" | "urgent" | "planned">("critical");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");
  const [secs, setSecs] = useState(60);
  const [progress, setProgress] = useState(0);
  const [escalate, setEscalate] = useState(300);

  // 60-second form timer
  useEffect(() => {
    if (phase !== "form") return;
    const id = setInterval(() => setSecs((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [phase]);

  useEffect(() => { if (sp.auto && sp.group) start(); }, []); // eslint-disable-line

  // 5-minute auto-escalation countdown
  useEffect(() => {
    if (phase !== "results") return;
    const id = setInterval(() => setEscalate((s) => {
      if (s <= 1) { toast.warning("No reply — alerting next 5 sources, radius widened to 15 km"); return 300; }
      return s - 1;
    }), 1000);
    return () => clearInterval(id);
  }, [phase]);

  async function start() {
    setPhase("searching"); setProgress(0);
    for (let i = 1; i <= 4; i++) { await new Promise((r) => setTimeout(r, 900)); setProgress(i); }
    const top = rankSources(group).slice(0, 5);
    await notifySources(top.map((s) => s.id));
    if (phone && top[0]) await smsFallback(phone, `HemoPulse: ${top[0].name} accepted. ${top[0].address}. Ph ${top[0].phone}. ETA 18 min.`);
    setPhase("results");
  }

  const steps = [
    { icon: Radar, text: "Searching 12 blood banks within 5 km…" },
    { icon: Radar, text: "Checking 48 eligible donors & expiry dates…" },
    { icon: BellRing, text: "Notifying top 5 matches by push, SMS & WhatsApp…" },
    { icon: CheckCircle2, text: "AIIMS Blood Bank accepted! Others released." },
  ];

  if (phase === "searching") return (
    <div className="mx-auto max-w-xl px-4 py-16 text-center">
      <div className="mx-auto flex h-28 w-28 animate-heartbeat items-center justify-center rounded-full bg-crimson text-primary-foreground shadow-lift"><Radar className="h-14 w-14" /></div>
      <h1 className="mt-6 text-3xl font-extrabold">Finding {group} blood…</h1>
      <ul className="mt-8 space-y-3 text-left">
        {steps.map((s, i) => (
          <li key={i} className={`flex items-center gap-3 rounded-2xl border p-4 ${i < progress ? "bg-safe-soft" : i === progress ? "bg-card" : "bg-card opacity-40"}`}>
            <s.icon className={`h-6 w-6 ${i < progress ? "text-safe" : "text-primary"}`} /> <span className="font-medium">{s.text}</span>
          </li>
        ))}
      </ul>
    </div>
  );

  if (phase === "results") return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="mb-6 rounded-3xl bg-safe-soft p-6">
        <h1 className="flex items-center gap-2 text-2xl font-extrabold text-safe"><CheckCircle2 /> AIIMS Blood Bank accepted your request</h1>
        <p className="mt-1">{units} unit(s) of {group} · Request ID HP-48213</p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Link to="/track/$id" params={{ id: "HP-48213" }} className="inline-flex h-12 items-center rounded-full bg-navy px-6 font-bold text-primary-foreground">{t("trackLive")}</Link>
          <button onClick={async () => { const r = await dispatchAmbulance(location); toast.success(`Ambulance ${r.vehicle} dispatched · ETA ${r.etaMin} min`); }}
            className="inline-flex h-12 items-center gap-2 rounded-full bg-crimson px-6 font-bold text-primary-foreground"><Ambulance /> {t("arrangeAmbulance")}</button>
          <button onClick={() => toast.success("Details sent by SMS")} className="inline-flex h-12 items-center gap-2 rounded-full border bg-card px-6 font-medium"><MessageSquare /> SMS me details</button>
        </div>
        <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground"><Timer className="h-4 w-4" /> Auto-escalation if any notified source doesn't reply in {Math.floor(escalate / 60)}:{String(escalate % 60).padStart(2, "0")}</p>
      </div>
      <ResultsView group={group} />
      <p className="mt-6 text-sm text-muted-foreground">{t("disclaimer")}</p>
    </div>
  );

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="mb-5 flex items-center justify-between gap-3">
        <h1 className="flex items-center gap-2 text-3xl font-extrabold text-primary"><Siren className="animate-heartbeat" /> {t("emergency")}</h1>
        <span className="flex items-center gap-2 rounded-full bg-card px-4 py-2 font-bold shadow-soft"><Timer className="h-5 w-5 text-primary" /> {secs}s</span>
      </div>
      <div className="mb-6 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full bg-crimson transition-all" style={{ width: `${((60 - secs) / 60) * 100}%` }} /></div>
      <form onSubmit={(e) => { e.preventDefault(); if (!location || !phone) { toast.error("Please add location and contact number"); return; } start(); }} className="space-y-5 rounded-3xl border bg-card p-5 shadow-soft md:p-7">
        <div>
          <span className="mb-2 block font-semibold">{t("bloodGroup")} *</span>
          <div className="grid grid-cols-4 gap-2">
            {BLOOD_GROUPS.map((g) => (
              <button type="button" key={g} onClick={() => setGroup(g)} aria-pressed={group === g} className={`h-14 rounded-2xl border-2 text-lg font-extrabold ${group === g ? "border-primary bg-primary text-primary-foreground" : "bg-background"}`}>{g}</button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <label><span className="mb-2 block font-semibold">{t("units")} *</span>
            <div className="flex h-14 items-center rounded-2xl border">
              <button type="button" onClick={() => setUnits(Math.max(1, units - 1))} className="h-full w-14 text-2xl font-bold">−</button>
              <span className="flex-1 text-center text-xl font-bold">{units}</span>
              <button type="button" onClick={() => setUnits(units + 1)} className="h-full w-14 text-2xl font-bold">+</button>
            </div>
          </label>
          <label><span className="mb-2 block font-semibold">{t("urgency")}</span>
            <select value={urgency} onChange={(e) => setUrgency(e.target.value as typeof urgency)} className={field}>
              <option value="critical">{t("critical")}</option><option value="urgent">{t("urgent")}</option><option value="planned">{t("planned")}</option>
            </select>
          </label>
        </div>
        <label className="block"><span className="mb-2 block font-semibold">{t("location")} *</span>
          <div className="flex gap-2">
            <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Hospital / area" className={field} />
            <button type="button" onClick={() => navigator.geolocation?.getCurrentPosition((p) => setLocation(`${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`))} className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border" aria-label={t("useLocation")}><LocateFixed /></button>
          </div>
        </label>
        <div className="grid gap-4 sm:grid-cols-2">
          <label><span className="mb-2 block font-semibold">{t("patientName")}</span><input value={name} onChange={(e) => setName(e.target.value)} className={field} /></label>
          <label><span className="mb-2 block font-semibold">{t("contact")} *</span><input value={phone} onChange={(e) => setPhone(e.target.value)} type="tel" inputMode="tel" placeholder="+91" className={field} /></label>
        </div>
        <label className="block"><span className="mb-2 block font-semibold">{t("doctorNote")}</span><textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} className="w-full rounded-2xl border bg-background p-4 text-lg" /></label>
        <button className="flex h-16 w-full items-center justify-center gap-2 rounded-2xl bg-crimson text-xl font-extrabold text-primary-foreground shadow-lift"><Siren /> {t("sendRequest")}</button>
        <p className="text-center text-sm text-muted-foreground">No login needed · If you go offline, updates come by SMS</p>
      </form>
    </div>
  );
}
