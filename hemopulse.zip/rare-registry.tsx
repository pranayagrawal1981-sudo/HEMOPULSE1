import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Gem, Lock, BadgeCheck, Snowflake, Upload, Clock } from "lucide-react";
import { FROZEN_UNITS, RARE_DONORS } from "@/lib/mock-data";

export const Route = createFileRoute("/rare-registry")({
  head: () => ({
    meta: [
      { title: "Rare Donor Registry (Bombay hh, Rh-null) — HemoPulse" },
      { name: "description", content: "Verified, consent-first registry for Bombay blood group and Rh-null donors, plus cryopreserved rare units." },
      { property: "og:title", content: "Rare Donor Registry — HemoPulse" },
      { property: "og:description", content: "Private, verified registry for the rarest blood types in India." },
    ],
  }),
  component: Rare,
});

function Rare() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="rounded-3xl bg-crimson p-8 text-primary-foreground">
        <Gem className="h-12 w-12" />
        <h1 className="mt-3 text-3xl font-extrabold md:text-4xl">Rare Donor Registry</h1>
        <p className="mt-2 max-w-2xl opacity-90">For Bombay (hh) and Rh-null donors. Verified by OTP and lab report. Your contact stays hidden until you consent to each request.</p>
        <div className="mt-5 flex flex-wrap gap-3 text-sm font-medium">
          <span className="rounded-full bg-card/20 px-4 py-2">1. City alert</span>
          <span className="rounded-full bg-card/20 px-4 py-2">2. State alert</span>
          <span className="rounded-full bg-card/20 px-4 py-2">3. National alert</span>
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl border bg-card p-6 shadow-soft">
          <h2 className="text-xl font-bold">Join the registry</h2>
          <ol className="mt-4 space-y-3">
            <li className="flex gap-3"><BadgeCheck className="text-safe" /> Verify your mobile with OTP</li>
            <li className="flex gap-3"><Upload className="text-primary" /> Upload your lab test report</li>
            <li className="flex gap-3"><Lock className="text-navy" /> Choose consent settings</li>
          </ol>
          <div className="mt-5 flex flex-wrap gap-3">
            <Link to="/login" search={{ role: "donor" }} className="inline-flex h-12 items-center rounded-full bg-crimson px-6 font-bold text-primary-foreground">Verify with OTP</Link>
            <label className="inline-flex h-12 cursor-pointer items-center gap-2 rounded-full border px-5 font-medium">
              <Upload className="h-4 w-4" /> Upload report
              <input type="file" accept="image/*,.pdf" className="sr-only" onChange={() => toast.success("Report uploaded — pending lab verification")} />
            </label>
          </div>
        </div>
        <div className="rounded-3xl border bg-card p-6 shadow-soft">
          <h2 className="flex items-center gap-2 text-xl font-bold"><Snowflake className="text-primary" /> Frozen / cryopreserved rare units</h2>
          <ul className="mt-4 divide-y">
            {FROZEN_UNITS.map((f) => (
              <li key={f.bank} className="flex items-center justify-between py-3">
                <div><p className="font-semibold">{f.bank}</p><p className="text-sm text-muted-foreground">{f.city} · {f.type}</p></div>
                <span className="rounded-full bg-secondary px-3 py-1 font-bold text-primary">{f.units} units</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <h2 className="mt-10 text-2xl font-bold">Registered donors (anonymised)</h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {RARE_DONORS.map((d) => (
          <div key={d.id} className="rounded-3xl border bg-card p-5 shadow-soft">
            <p className="font-mono text-sm text-muted-foreground">{d.code}</p>
            <p className="mt-1 text-lg font-bold text-primary">{d.type}</p>
            <p>{d.city}, {d.state}</p>
            <p className={`mt-3 inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm font-semibold ${d.verified ? "bg-safe-soft text-safe" : "bg-warn-soft text-warn"}`}>
              {d.verified ? <><BadgeCheck className="h-4 w-4" /> Verified</> : <><Clock className="h-4 w-4" /> Pending</>}
            </p>
            <p className="mt-3 flex items-center gap-1 text-sm text-muted-foreground"><Lock className="h-4 w-4" /> Contact hidden until consent</p>
          </div>
        ))}
      </div>
    </div>
  );
}
