import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { BLOOD_GROUPS } from "@/lib/mock-data";
import { ResultsView } from "@/components/hp/ResultsView";
import { LiveBadge } from "@/components/hp/StockStrip";
import { useI18n } from "@/lib/i18n";

const schema = z.object({ group: z.enum(BLOOD_GROUPS).catch("O+"), city: z.string().catch("New Delhi") });

export const Route = createFileRoute("/search")({
  validateSearch: (s) => schema.parse(s),
  head: () => ({
    meta: [
      { title: "Blood search results — HemoPulse" },
      { name: "description", content: "Nearby blood banks, hospitals and donors ranked by compatibility, distance and freshness." },
      { property: "og:title", content: "Blood search results — HemoPulse" },
      { property: "og:description", content: "Ranked nearby blood sources with call, map and directions." },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { group, city } = Route.useSearch();
  const { t } = useI18n();
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <h1 className="text-3xl font-extrabold"><span className="text-primary">{group}</span> · {city}</h1>
        <LiveBadge />
      </div>
      <ResultsView group={group} />
      <p className="mt-6 text-sm text-muted-foreground">{t("disclaimer")}</p>
    </div>
  );
}
