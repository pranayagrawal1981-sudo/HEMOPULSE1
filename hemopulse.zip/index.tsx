import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Siren, Search, LocateFixed, ClipboardList, Cpu, Radio, ShieldCheck, BadgeCheck, Lock, Gem } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { BLOOD_GROUPS, type BloodGroup } from "@/lib/mock-data";
import { StockStrip } from "@/components/hp/StockStrip";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HemoPulse — Find the right blood in minutes" },
      { name: "description", content: "AI-powered real-time blood finder for India. Emergency requests without login, live stock, donation camps and rare donor registry." },
      { property: "og:title", content: "HemoPulse — Find the right blood in minutes" },
      { property: "og:description", content: "Emergency blood requests, live stock and donation camps across India." },
    ],
  }),
  component: Home,
});

function Home() {
  const { t } = useI18n();
  const nav = useNavigate();
  const [group, setGroup] = useState<BloodGroup>("O+");
  const [city, setCity] = useState("");
  const [locating, setLocating] = useState(false);

  const locate = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (p) => { setCity(`${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)}`); setLocating(false); },
      () => setLocating(false),
    );
  };

  const steps = [
    { icon: ClipboardList, title: t("step1"), d: t("step1d") },
    { icon: Cpu, title: t("step2"), d: t("step2d") },
    { icon: Radio, title: t("step3"), d: t("step3d") },
  ];

  return (
    <>
      <section className="bg-hero">
        <div className="mx-auto max-w-7xl px-4 pb-14 pt-12 md:pt-20">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-card px-4 py-2 text-sm font-medium shadow-soft">
            <ShieldCheck className="h-4 w-4 text-safe" /> 1,240 verified blood banks · 38,000 donors
          </p>
          <h1 className="max-w-3xl text-4xl font-extrabold leading-tight tracking-tight text-navy md:text-6xl">
            {t("tagline")}
          </h1>
          <div className="mt-8 grid max-w-3xl gap-4 sm:grid-cols-2">
            <Link to="/emergency" className="animate-ring flex items-center gap-4 rounded-3xl bg-crimson p-6 text-primary-foreground shadow-lift">
              <Siren className="h-10 w-10 shrink-0 animate-heartbeat" />
              <span><span className="block text-xl font-extrabold leading-tight">{t("heroEmergency")}</span><span className="text-sm opacity-90">{t("heroEmergencySub")}</span></span>
            </Link>
            <a href="#quick-search" className="flex items-center gap-4 rounded-3xl border-2 border-navy bg-card p-6 text-navy shadow-soft">
              <Search className="h-10 w-10 shrink-0" />
              <span className="text-xl font-extrabold">{t("findBlood")}</span>
            </a>
          </div>

          <form id="quick-search" onSubmit={(e) => { e.preventDefault(); nav({ to: "/search", search: { group, city: city || "New Delhi" } }); }}
            className="mt-10 grid gap-3 rounded-3xl border bg-card p-4 shadow-soft md:grid-cols-[auto_1fr_auto] md:items-end">
            <label className="block">
              <span className="mb-1 block text-sm font-medium">{t("bloodGroup")}</span>
              <select value={group} onChange={(e) => setGroup(e.target.value as BloodGroup)} className="h-14 w-full rounded-2xl border bg-background px-4 text-lg font-bold md:w-36">
                {BLOOD_GROUPS.map((g) => <option key={g}>{g}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="mb-1 block text-sm font-medium">{t("city")}</span>
              <div className="flex gap-2">
                <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="New Delhi" className="h-14 min-w-0 flex-1 rounded-2xl border bg-background px-4 text-lg" />
                <button type="button" onClick={locate} className="flex h-14 items-center gap-2 rounded-2xl border px-4 font-medium"><LocateFixed className="h-5 w-5" /><span className="hidden sm:inline">{locating ? t("detecting") : t("useLocation")}</span></button>
              </div>
            </label>
            <button className="flex h-14 items-center justify-center gap-2 rounded-2xl bg-navy px-8 text-lg font-bold text-primary-foreground"><Search className="h-5 w-5" />{t("search")}</button>
          </form>
        </div>
      </section>

      <div className="-mt-2"><StockStrip /></div>

      <section className="mx-auto max-w-7xl px-4 pt-16">
        <h2 className="text-3xl font-extrabold">{t("howItWorks")}</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {steps.map((s, i) => (
            <div key={i} className="rounded-3xl border bg-card p-6 shadow-soft">
              <div className="flex items-center gap-3"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-primary"><s.icon /></span><span className="text-4xl font-extrabold text-border">0{i + 1}</span></div>
              <h3 className="mt-4 text-xl font-bold">{s.title}</h3>
              <p className="mt-1 text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pt-16">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {[["58s", "Avg. match time"], ["12,400+", "Lives supported"], ["1,240", "Verified banks"], ["96%", "Requests fulfilled"]].map(([n, l]) => (
            <div key={l} className="rounded-3xl bg-navy p-6 text-primary-foreground"><div className="text-3xl font-extrabold">{n}</div><div className="opacity-80">{l}</div></div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          {[[BadgeCheck, "License-verified banks"], [ShieldCheck, "OTP-verified donors"], [Lock, "Encrypted & consent-first"]].map(([I, l]) => {
            const Icon = I as typeof Lock;
            return <span key={l as string} className="inline-flex items-center gap-2 rounded-full border bg-card px-4 py-2 font-medium"><Icon className="h-5 w-5 text-safe" />{l as string}</span>;
          })}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pt-16">
        <div className="flex flex-col items-start gap-5 rounded-3xl bg-crimson p-8 text-primary-foreground md:flex-row md:items-center md:p-10">
          <Gem className="h-14 w-14 shrink-0" />
          <div className="flex-1">
            <h2 className="text-2xl font-extrabold">{t("rareRegistry")}</h2>
            <p className="mt-1 opacity-90">Bombay (hh) and Rh-null donors — verified, private, and alerted city → state → country.</p>
          </div>
          <Link to="/rare-registry" className="inline-flex h-12 items-center rounded-full bg-card px-6 font-bold text-primary">Open registry</Link>
        </div>
      </section>
    </>
  );
}
