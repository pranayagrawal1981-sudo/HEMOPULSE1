import { useEffect, useState } from "react";
import { BLOOD_GROUPS, levelFor, type BloodGroup } from "@/lib/mock-data";
import { subscribeStock } from "@/lib/integrations";
import { useI18n } from "@/lib/i18n";

export const levelCls = {
  low: "bg-critical-soft text-critical border-critical/30",
  safe: "bg-safe-soft text-safe border-safe/30",
  surplus: "bg-secondary text-navy border-border",
};

export function LiveBadge({ at }: { at?: Date | undefined }) {
  const { t } = useI18n();
  return (
    <span className="inline-flex items-center gap-2 rounded-full bg-safe-soft px-3 py-1 text-sm font-medium text-safe">
      <span className="animate-live h-2 w-2 rounded-full bg-safe" /> {t("live")}
      {at && <span className="text-muted-foreground">· {t("updated")} {at.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span>}
    </span>
  );
}

export function StockStrip() {
  const { t } = useI18n();
  const [stock, setStock] = useState<Record<BloodGroup, number> | null>(null);
  const [at, setAt] = useState<Date>();
  useEffect(() => subscribeStock((s) => { setStock(s); setAt(new Date()); }), []);
  return (
    <section className="mx-auto max-w-7xl px-4">
      <div className="rounded-3xl border bg-card p-5 shadow-soft md:p-7">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-xl font-bold">{t("liveStock")} · New Delhi</h2>
          <LiveBadge at={at} />
        </div>
        <div className="grid grid-cols-4 gap-3 md:grid-cols-8">
          {BLOOD_GROUPS.map((g) => {
            const u = stock?.[g] ?? 0;
            const lvl = levelFor(u);
            return (
              <div key={g} className={`rounded-2xl border p-3 text-center ${levelCls[lvl]}`}>
                <div className="text-xl font-extrabold">{g}</div>
                <div className="text-2xl font-bold text-navy">{stock ? u : "–"}</div>
                <div className="text-xs font-semibold uppercase">{t(lvl)}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
