import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/dashboard/center")({
  head: () => ({
    meta: [
      { title: "Center dashboard — HemoPulse" },
      { name: "description", content: "HemoPulse center dashboard." },
      { property: "og:title", content: "Center dashboard — HemoPulse" },
      { property: "og:description", content: "HemoPulse center dashboard." },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <h1 className="text-3xl font-extrabold">Center dashboard</h1>
      <p className="mt-3 text-muted-foreground">Coming soon.</p>
    </div>
  ),
});
