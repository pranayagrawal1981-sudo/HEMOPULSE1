import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone, ShieldCheck } from "lucide-react";
import { Logo } from "./Logo";
import { LANGS, useI18n } from "@/lib/i18n";
import { OWNER } from "@/lib/mock-data";

export function Footer() {
  const { t, lang, setLang } = useI18n();
  return (
    <footer className="mt-20 border-t bg-card">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo />
          <p className="mt-3 text-muted-foreground">{t("tagline")}</p>
          <div className="mt-4 flex gap-2">
            {LANGS.map((l) => (
              <button key={l.code} onClick={() => setLang(l.code)} className={`h-10 rounded-full border px-4 text-sm ${lang === l.code ? "bg-primary text-primary-foreground" : ""}`}>{l.label}</button>
            ))}
          </div>
        </div>
        <div>
          <h3 className="font-semibold">{t("helpline")}</h3>
          <a href="tel:1800110011" className="mt-2 block text-2xl font-bold text-primary">1800-11-0011</a>
          <p className="text-sm text-muted-foreground">Ambulance: <a href="tel:108" className="font-semibold">108</a></p>
        </div>
        <div className="flex flex-col gap-2">
          <Link to="/emergency" className="hover:text-primary">{t("emergency")}</Link>
          <Link to="/camps" className="hover:text-primary">{t("camps")}</Link>
          <Link to="/rare-registry" className="hover:text-primary">{t("rareRegistry")}</Link>
          <Link to="/privacy" className="hover:text-primary">{t("privacy")}</Link>
        </div>
        <div id="contact">
          <h3 className="font-semibold">{t("contactOwner")}</h3>
          <ul className="mt-3 space-y-2 text-muted-foreground">
            <li className="font-medium text-foreground">{OWNER.name}</li>
            <li><a href={`mailto:${OWNER.email}`} className="flex items-center gap-2 hover:text-primary"><Mail className="h-4 w-4" />{OWNER.email}</a></li>
            <li><a href={`tel:${OWNER.phone.replace(/\s/g, "")}`} className="flex items-center gap-2 hover:text-primary"><Phone className="h-4 w-4" />{OWNER.phone}</a></li>
            <li className="flex items-center gap-2"><MapPin className="h-4 w-4" />{OWNER.address}</li>
          </ul>
        </div>
      </div>
      <div className="border-t">
        <p className="mx-auto flex max-w-7xl items-center gap-2 px-4 py-4 text-sm text-muted-foreground">
          <ShieldCheck className="h-4 w-4 text-safe" /> {t("disclaimer")} © 2026 HemoPulse
        </p>
      </div>
    </footer>
  );
}
