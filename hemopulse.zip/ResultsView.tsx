import { useState } from "react";
import { List, Map as MapIcon } from "lucide-react";
import { rankSources, type BloodGroup } from "@/lib/mock-data";
import { mapEmbedUrl } from "@/lib/integrations";
import { ResultCard } from "./ResultCard";
import { useI18n } from "@/lib/i18n";

export function ResultsView({ group }: { group: BloodGroup }) {
  const { t } = useI18n();
  const results = rankSources(group);
  const [view, setView] = useState<"list" | "map">("list");
  const [focus, setFocus] = useState(results[0]!);
  return (
    <div>
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="text-muted-foreground">{results.length} matches · ranked by compatibility, distance, freshness</p>
        <div className="flex rounded-full border bg-card p-1">
          {(["list", "map"] as const).map((v) => (
            <button key={v} onClick={() => setView(v)} aria-pressed={view === v} className={`inline-flex h-10 items-center gap-2 rounded-full px-4 font-medium ${view === v ? "bg-primary text-primary-foreground" : ""}`}>
              {v === "list" ? <List className="h-4 w-4" /> : <MapIcon className="h-4 w-4" />} {t(v)}
            </button>
          ))}
        </div>
      </div>
      <div className={`grid gap-5 ${view === "map" ? "lg:grid-cols-[1fr_1.1fr]" : "lg:grid-cols-[1.4fr_1fr]"}`}>
        <div className={`space-y-4 ${view === "map" ? "hidden lg:block" : ""}`}>
          {results.map((s) => <ResultCard key={s.id} s={s} onMap={() => { setFocus(s); setView("map"); }} />)}
        </div>
        <div className={`${view === "list" ? "hidden lg:block" : ""}`}>
          {/* [MAPS] Replace with Google Maps JS API (markers for all results + Routes API ETA) */}
          <div className="sticky top-24 overflow-hidden rounded-3xl border bg-card shadow-soft">
            <iframe title="Map" src={mapEmbedUrl(`${focus.lat},${focus.lng}`)} className="h-[420px] w-full lg:h-[560px]" loading="lazy" />
            <div className="p-4">
              <p className="font-bold">{focus.name}</p>
              <p className="text-sm text-muted-foreground">{focus.distanceKm} km · ~{Math.round(focus.distanceKm * 3 + 4)} min by road</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
