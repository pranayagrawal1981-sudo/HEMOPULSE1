import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown, Menu, Siren, Type, X, Globe } from "lucide-react";
import { Logo } from "./Logo";
import { LANGS, useI18n } from "@/lib/i18n";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function EmergencyButton({ size = "md" }: { size?: "md" | "sm" }) {
  const { t } = useI18n();
  return (
    <Link
      to="/emergency"
      className={`animate-ring inline-flex items-center gap-2 rounded-full bg-crimson font-bold text-primary-foreground shadow-lift ${size === "sm" ? "h-11 px-4 text-sm" : "h-12 px-5"}`}
    >
      <Siren className="h-5 w-5" /> {t("emergency")}
    </Link>
  );
}

function LangToggle() {
  const { lang, setLang } = useI18n();
  return (
    <div className="flex h-11 items-center rounded-full border bg-card p-1" role="group" aria-label="Language">
      <Globe className="mx-1 h-4 w-4 text-muted-foreground" />
      {LANGS.map((l) => (
        <button
          key={l.code}
          onClick={() => setLang(l.code)}
          aria-pressed={lang === l.code}
          className={`h-9 rounded-full px-3 text-sm font-medium ${lang === l.code ? "bg-primary text-primary-foreground" : "text-foreground"}`}
        >
          {l.label}
        </button>
      ))}
    </div>
  );
}

function TextSizeToggle() {
  const { t } = useI18n();
  const [big, setBig] = useState(false);
  return (
    <button
      onClick={() => { setBig(!big); document.documentElement.classList.toggle("text-large"); }}
      aria-pressed={big}
      title={t("textSize")}
      className={`flex h-11 w-11 items-center justify-center rounded-full border ${big ? "bg-secondary text-secondary-foreground" : "bg-card"}`}
    >
      <Type className="h-5 w-5" /><span className="sr-only">{t("textSize")}</span>
    </button>
  );
}

const linkCls = "inline-flex h-11 items-center gap-1 rounded-full px-4 font-medium hover:bg-accent";

export function Navbar() {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-18 max-w-7xl items-center gap-3 px-4 py-3">
        <Link to="/" aria-label="HemoPulse home"><Logo /></Link>
        <nav className="ml-6 hidden items-center gap-1 lg:flex">
          <Link to="/" className={linkCls} activeProps={{ className: "text-primary" }} activeOptions={{ exact: true }}>{t("home")}</Link>
          <DropdownMenu>
            <DropdownMenuTrigger className={linkCls}>{t("login")} <ChevronDown className="h-4 w-4" /></DropdownMenuTrigger>
            <DropdownMenuContent className="w-56">
              <DropdownMenuItem asChild><Link to="/login" search={{ role: "donor" }} className="h-11">{t("donorLogin")}</Link></DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/login" search={{ role: "receiver" }} className="h-11">{t("receiverLogin")}</Link></DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/login" search={{ role: "center" }} className="h-11">{t("centerLogin")}</Link></DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger className={linkCls}>{t("wantDonate")} <ChevronDown className="h-4 w-4" /></DropdownMenuTrigger>
            <DropdownMenuContent className="w-56">
              <DropdownMenuItem asChild><Link to="/camps" className="h-11">{t("camps")}</Link></DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/rare-registry" className="h-11">{t("rareRegistry")}</Link></DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <div className="hidden items-center gap-2 md:flex"><TextSizeToggle /><LangToggle /></div>
          <EmergencyButton size="sm" />
          <button className="flex h-11 w-11 items-center justify-center rounded-full border lg:hidden" onClick={() => setOpen(!open)} aria-label="Menu" aria-expanded={open}>
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
      {open && (
        <div className="border-t bg-background px-4 pb-5 lg:hidden" onClick={(e) => (e.target as HTMLElement).closest("a") && setOpen(false)}>
          <div className="flex flex-col gap-1 py-3 text-lg">
            <Link to="/" className="py-3">{t("home")}</Link>
            <p className="pt-2 text-sm font-semibold uppercase text-muted-foreground">{t("login")}</p>
            <Link to="/login" search={{ role: "donor" }} className="py-3">{t("donorLogin")}</Link>
            <Link to="/login" search={{ role: "receiver" }} className="py-3">{t("receiverLogin")}</Link>
            <Link to="/login" search={{ role: "center" }} className="py-3">{t("centerLogin")}</Link>
            <p className="pt-2 text-sm font-semibold uppercase text-muted-foreground">{t("wantDonate")}</p>
            <Link to="/camps" className="py-3">{t("camps")}</Link>
            <Link to="/rare-registry" className="py-3">{t("rareRegistry")}</Link>
          </div>
          <div className="flex gap-2"><TextSizeToggle /><LangToggle /></div>
        </div>
      )}
    </header>
  );
}
