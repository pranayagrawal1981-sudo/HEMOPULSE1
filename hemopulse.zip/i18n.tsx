/**
 * Lightweight i18n. Add a new language by adding a key to `dict`
 * (e.g. "ta", "bn") and an entry in LANGS. Missing keys fall back to English.
 */
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export const LANGS = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिन्दी" },
] as const;
export type Lang = (typeof LANGS)[number]["code"];

const en = {
  tagline: "The right blood. The right person. In minutes.",
  home: "Home", login: "Login", donorLogin: "Donor Login", receiverLogin: "Receiver Login",
  centerLogin: "Blood Center Login", wantDonate: "Want to Donate", camps: "Blood Donation Camp",
  rareRegistry: "Rare Donor Registry", emergency: "EMERGENCY",
  heroEmergency: "EMERGENCY – I need blood now", heroEmergencySub: "No login needed",
  findBlood: "Find Blood", bloodGroup: "Blood group", city: "City or area", useLocation: "Use my location",
  search: "Search", liveStock: "Live blood stock", live: "Live", updated: "Updated",
  low: "Low", safe: "Safe", surplus: "Surplus", howItWorks: "How it works",
  step1: "Fill request", step1d: "Blood group, units, location. Under 60 seconds.",
  step2: "AI finds source", step2d: "Ranks banks, hospitals & donors by match, distance and freshness.",
  step3: "Accept & track", step3d: "First to accept wins. Track it live till it reaches you.",
  units: "Units", location: "Location", patientName: "Patient name", contact: "Contact number",
  doctorNote: "Doctor note (optional)", urgency: "Urgency", critical: "Critical", urgent: "Urgent",
  planned: "Planned", sendRequest: "Send emergency request", detecting: "Detecting…",
  call: "Call", viewMap: "View on map", directions: "Directions", list: "List", map: "Map",
  accepted: "Accepted", notified: "Notified", expires: "Expires", kmAway: "km away",
  minAgo: "min ago", trackLive: "Track live", arrangeAmbulance: "Arrange Mobile Ambulance",
  doctorConfirm: "Doctor confirmation needed", helpline: "24×7 Helpline",
  assistant: "HemoPulse Assistant", askAnything: "Type or speak…", callAI: "Call AI assistant",
  sendOtp: "Send OTP", verify: "Verify", mobile: "Mobile number", enterOtp: "Enter 6-digit OTP",
  resendIn: "Resend in", resend: "Resend OTP", privacy: "Privacy & Consent",
  contactOwner: "Contact the website owner", textSize: "Larger text",
  disclaimer: "Blood group substitutions must always be confirmed by a doctor or hospital.",
  register: "Register", remindMe: "Remind me", dashboard: "Dashboard", logout: "Logout",
  hidden: "Hidden until consent",
};
type Dict = typeof en;
export type TKey = keyof Dict;

const hi: Partial<Dict> = {
  tagline: "सही खून। सही व्यक्ति। कुछ ही मिनटों में।",
  home: "होम", login: "लॉगिन", donorLogin: "दाता लॉगिन", receiverLogin: "प्राप्तकर्ता लॉगिन",
  centerLogin: "ब्लड सेंटर लॉगिन", wantDonate: "रक्तदान करें", camps: "रक्तदान शिविर",
  rareRegistry: "दुर्लभ दाता रजिस्ट्री", emergency: "आपातकाल",
  heroEmergency: "आपातकाल – मुझे अभी खून चाहिए", heroEmergencySub: "लॉगिन की ज़रूरत नहीं",
  findBlood: "खून खोजें", bloodGroup: "ब्लड ग्रुप", city: "शहर या इलाका", useLocation: "मेरा लोकेशन",
  search: "खोजें", liveStock: "लाइव ब्लड स्टॉक", live: "लाइव", updated: "अपडेट",
  low: "कम", safe: "पर्याप्त", surplus: "अधिक", howItWorks: "यह कैसे काम करता है",
  step1: "अनुरोध भरें", step1d: "ब्लड ग्रुप, यूनिट, लोकेशन। 60 सेकंड से कम।",
  step2: "AI स्रोत खोजता है", step2d: "मिलान, दूरी और ताज़गी के आधार पर रैंकिंग।",
  step3: "स्वीकार करें और ट्रैक करें", step3d: "जो पहले स्वीकार करे वही। लाइव ट्रैक करें।",
  units: "यूनिट", location: "लोकेशन", patientName: "मरीज़ का नाम", contact: "संपर्क नंबर",
  doctorNote: "डॉक्टर नोट (वैकल्पिक)", urgency: "तात्कालिकता", critical: "गंभीर", urgent: "जल्दी",
  planned: "नियोजित", sendRequest: "आपातकालीन अनुरोध भेजें", detecting: "पता लगा रहे हैं…",
  call: "कॉल करें", viewMap: "मैप पर देखें", directions: "रास्ता", list: "सूची", map: "मैप",
  accepted: "स्वीकृत", notified: "सूचित", expires: "समाप्ति", kmAway: "किमी दूर",
  minAgo: "मिनट पहले", trackLive: "लाइव ट्रैक करें", arrangeAmbulance: "मोबाइल एम्बुलेंस बुलाएँ",
  doctorConfirm: "डॉक्टर की पुष्टि आवश्यक", helpline: "24×7 हेल्पलाइन",
  assistant: "हीमोपल्स सहायक", askAnything: "लिखें या बोलें…", callAI: "AI सहायक को कॉल करें",
  sendOtp: "OTP भेजें", verify: "सत्यापित करें", mobile: "मोबाइल नंबर", enterOtp: "6 अंकों का OTP डालें",
  resendIn: "दोबारा भेजें", resend: "OTP दोबारा भेजें", privacy: "गोपनीयता और सहमति",
  contactOwner: "वेबसाइट मालिक से संपर्क करें", textSize: "बड़ा टेक्स्ट",
  disclaimer: "ब्लड ग्रुप का विकल्प हमेशा डॉक्टर या अस्पताल द्वारा पुष्टि किया जाना चाहिए।",
  register: "रजिस्टर करें", remindMe: "याद दिलाएँ", dashboard: "डैशबोर्ड", logout: "लॉगआउट",
  hidden: "सहमति तक छिपा हुआ",
};

const dict: Record<Lang, Partial<Dict>> = { en, hi };

const Ctx = createContext<{ lang: Lang; setLang: (l: Lang) => void; t: (k: TKey) => string }>({
  lang: "en", setLang: () => {}, t: (k) => en[k],
});

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  useEffect(() => {
    const saved = localStorage.getItem("hp-lang") as Lang | null;
    if (saved && saved in dict) setLangState(saved);
  }, []);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const setLang = (l: Lang) => { setLangState(l); localStorage.setItem("hp-lang", l); };
  const t = (k: TKey) => dict[lang][k] ?? en[k];
  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
}
export const useI18n = () => useContext(Ctx);
