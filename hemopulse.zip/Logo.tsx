export function LogoMark({ className = "h-9 w-9", animated = false }: { className?: string; animated?: boolean }) {
  return (
    <svg viewBox="0 0 48 48" className={`${className} ${animated ? "animate-heartbeat" : ""}`} aria-hidden="true">
      <defs>
        <linearGradient id="hp-drop" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--color-primary)" />
          <stop offset="100%" stopColor="var(--color-primary-deep)" />
        </linearGradient>
      </defs>
      <path d="M24 3C24 3 8 21 8 31a16 16 0 0 0 32 0C40 21 24 3 24 3Z" fill="url(#hp-drop)" />
      <path d="M12 31h7l2.5-6 4 11 3-8 1.5 3H36" fill="none" stroke="var(--color-primary-foreground)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2">
      <LogoMark animated />
      {!compact && (
        <span className="text-xl font-extrabold tracking-tight">
          <span className="text-navy">HEMO</span>
          <span className="text-primary">PULSE</span>
        </span>
      )}
    </span>
  );
}
