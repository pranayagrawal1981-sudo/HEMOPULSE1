/**
 * MOCK DATA — replace with realtime database queries (see src/lib/integrations.ts).
 */
export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"] as const;
export type BloodGroup = (typeof BLOOD_GROUPS)[number];

export type StockLevel = "low" | "safe" | "surplus";
export const levelFor = (u: number): StockLevel => (u < 15 ? "low" : u < 60 ? "safe" : "surplus");

export const CITY_STOCK: Record<BloodGroup, number> = {
  "A+": 84, "A-": 9, "B+": 112, "B-": 6, "AB+": 41, "AB-": 3, "O+": 138, "O-": 12,
};

/** Who can receive from whom (red cell compatibility). */
export const COMPATIBLE: Record<BloodGroup, BloodGroup[]> = {
  "O-": ["O-"], "O+": ["O+", "O-"], "A-": ["A-", "O-"], "A+": ["A+", "A-", "O+", "O-"],
  "B-": ["B-", "O-"], "B+": ["B+", "B-", "O+", "O-"], "AB-": ["AB-", "A-", "B-", "O-"],
  "AB+": ["AB+", "AB-", "A+", "A-", "B+", "B-", "O+", "O-"],
};

export type Source = {
  id: string; name: string; type: "bank" | "hospital" | "donor";
  group: BloodGroup; units: number; expiryDays: number; updatedMin: number;
  distanceKm: number; phone: string; address: string; lat: number; lng: number;
  consent?: boolean; status: "accepted" | "notified" | "idle"; verified: boolean;
};

const base: Omit<Source, "group" | "status">[] = [
  { id: "s1", name: "AIIMS Blood Bank", type: "bank", units: 14, expiryDays: 21, updatedMin: 2, distanceKm: 3.2, phone: "+911126588500", address: "Ansari Nagar, New Delhi", lat: 28.5672, lng: 77.21, verified: true },
  { id: "s2", name: "Red Cross Blood Centre", type: "bank", units: 8, expiryDays: 2, updatedMin: 5, distanceKm: 4.8, phone: "+911123716441", address: "1 Red Cross Rd, New Delhi", lat: 28.6201, lng: 77.2135, verified: true },
  { id: "s3", name: "Safdarjung Hospital", type: "hospital", units: 5, expiryDays: 12, updatedMin: 9, distanceKm: 5.5, phone: "+911126707444", address: "Ring Road, New Delhi", lat: 28.5685, lng: 77.2066, verified: true },
  { id: "s4", name: "Rahul S. (Donor)", type: "donor", units: 1, expiryDays: 35, updatedMin: 1, distanceKm: 2.1, phone: "+919800000001", address: "Lajpat Nagar", lat: 28.5677, lng: 77.2433, consent: false, verified: true },
  { id: "s5", name: "Rotary Blood Bank", type: "bank", units: 22, expiryDays: 18, updatedMin: 14, distanceKm: 8.9, phone: "+911129054066", address: "Tughlakabad Inst. Area", lat: 28.5126, lng: 77.2634, verified: true },
  { id: "s6", name: "Priya M. (Donor)", type: "donor", units: 1, expiryDays: 35, updatedMin: 3, distanceKm: 6.4, phone: "+919800000002", address: "Saket", lat: 28.5245, lng: 77.2066, consent: true, verified: true },
];

/** Ranking score = compatibility + distance + freshness + donor eligibility. */
export function rankSources(group: BloodGroup): (Source & { score: number; alternative: boolean })[] {
  const compat = COMPATIBLE[group];
  return base
    .map((s, i) => {
      const g = compat[i % compat.length] ?? group;
      const exact = g === group;
      const score = (exact ? 40 : 25) + Math.max(0, 30 - s.distanceKm * 2.5) + Math.min(20, s.expiryDays) + (s.type === "donor" ? 8 : 10);
      return { ...s, group: g, alternative: !exact, score: Math.round(score), status: i === 0 ? "accepted" : i < 5 ? "notified" : "idle" } as Source & { score: number; alternative: boolean };
    })
    .filter((s) => s.expiryDays > 0) // expired units never shown
    .sort((a, b) => b.score - a.score);
}

export const CAMPS = [
  { id: "c1", name: "Mega Blood Donation Drive", org: "Rotary Club Delhi", date: "2026-10-08", time: "9:00 AM – 4:00 PM", address: "Connaught Place Central Park", km: 3.1, lat: 28.6315, lng: 77.2167 },
  { id: "c2", name: "Campus Life-Savers Camp", org: "Delhi University NSS", date: "2026-10-11", time: "10:00 AM – 3:00 PM", address: "North Campus, Arts Faculty", km: 11.4, lat: 28.6889, lng: 77.2100 },
  { id: "c3", name: "Corporate Donation Day", org: "Cyber City Assoc.", date: "2026-10-15", time: "11:00 AM – 5:00 PM", address: "DLF Cyber Hub, Gurugram", km: 19.8, lat: 28.4950, lng: 77.0895 },
  { id: "c4", name: "Navratri Seva Camp", org: "Sewa Bharati", date: "2026-10-19", time: "8:00 AM – 2:00 PM", address: "Lajpat Nagar Community Hall", km: 5.2, lat: 28.5677, lng: 77.2433 },
];

export const RARE_DONORS = [
  { id: "r1", code: "HH-DL-0021", type: "Bombay (hh)", city: "Delhi", state: "Delhi", verified: true },
  { id: "r2", code: "HH-MH-0107", type: "Bombay (hh)", city: "Mumbai", state: "Maharashtra", verified: true },
  { id: "r3", code: "RN-KA-0003", type: "Rh-null", city: "Bengaluru", state: "Karnataka", verified: true },
  { id: "r4", code: "HH-KA-0044", type: "Bombay (hh)", city: "Mysuru", state: "Karnataka", verified: false },
];

export const FROZEN_UNITS = [
  { bank: "Tata Memorial Rare Cell Bank", city: "Mumbai", type: "Bombay (hh)", units: 6 },
  { bank: "ISBT Cryo Unit", city: "Bengaluru", type: "Rh-null", units: 1 },
];

export const OWNER = {
  // TODO: replace with the real owner details
  name: "HemoPulse Team",
  email: "contact@hemopulse.in",
  phone: "+91 98765 43210",
  address: "New Delhi, India",
};
